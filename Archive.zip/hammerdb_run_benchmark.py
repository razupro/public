import argparse
import subprocess
import os
import time
import sys

# Global Configuration
hammerdb_cli_path = r"C:\Program Files\HammerDB\hammerdbcli.exe"
tcl_scripts_dir = os.path.join(os.path.expanduser("~"), "Downloads", "HammerDB_TCL_Scripts")
results_dir = os.path.join(os.path.expanduser("~"), "Downloads", "HammerDB_Results")

def run_hammerdb_tcl_script(script_path, log_prefix, results_file=None):
    """Runs a HammerDB CLI Tcl script, handling specific exit codes for known issues."""
    command = [hammerdb_cli_path, "tcl", "auto", script_path]
    print(f"\nRunning HammerDB CLI with script: '{script_path}' (using v5.0 syntax)")
    print(f"Executing: {' '.join(command)}")

    process = subprocess.run(command, capture_output=True, text=True, check=False) # Handle return code manually

    # Write captured stdout and stderr to the results file if provided
    if results_file:
        with open(results_file, "w") as outfile:
            outfile.write(process.stdout)
            outfile.write(process.stderr)

    # Print all captured output to the console for immediate visibility
    print(f"\n--- HammerDB CLI STDOUT ({log_prefix}) ---")
    print(process.stdout)
    print(f"--- HammerDB CLI STDERR ({log_prefix}) ---")
    print(process.stderr)
    print("------------------------------------------\n")

    # Check specifically for the disableRaw error when exit code is 1
    if process.returncode == 1 and "invalid command name \"disableRaw\"" in process.stderr:
        print(f"WARNING: HammerDB CLI for {log_prefix} exited with code 1 due to 'disableRaw' error. Benchmark likely completed successfully.")
        return True # Treat as success for workflow
    elif process.returncode != 0:
        print(f"FATAL ERROR: Command failed during {log_prefix} with exit code {process.returncode}.")
        print(f"Please review the full output above and in '{results_file}' for details.")
        return False
    else: # process.returncode == 0
        print(f"HammerDB CLI for {log_prefix} completed successfully.")
        return True

def main():
    parser = argparse.ArgumentParser(description="HammerDB Benchmark Run: Executes TPC-C workload.")
    parser.add_argument("--instance-name", required=True, help="SQL Server instance name.")
    parser.add_argument("--db-name", default="MyTPCCDatabase", help="Name of the TPC-C database.")
    parser.add_argument("--hammerdb-user", default="my_hammerdb_user", help="Dedicated SQL Server login/user for HammerDB.")
    parser.add_argument("--hammerdb-user-password", required=True, help="Password for the dedicated HammerDB user.")
    parser.add_argument("--warehouses", type=int, required=True, help="Number of TPC-C warehouses.")
    parser.add_argument("--virtual-users", nargs='+', type=int, required=True, help="List of Virtual Users (VUs) to test, e.g., 10 20 30.")
    parser.add_argument("--run-time-seconds", type=int, default=300, help="Duration of each benchmark run in seconds (default: 300).")
    parser.add_argument("--ramp-up-seconds", type=int, default=60, help="Ramp-up time for each benchmark run in seconds (default: 60).")

    args = parser.parse_args()

    os.makedirs(tcl_scripts_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    print("--- Starting HammerDB Benchmark Runs ---")

    for vu_count in args.virtual_users:
        print(f"\n--- Starting Benchmark for {vu_count} Virtual Users ---")
        
        # Convert seconds to minutes for HammerDB parameters
        rampup_minutes = args.ramp_up_seconds / 60
        duration_minutes = args.run_time_seconds / 60

        print(f"DEBUG: Calculated rampup_minutes = {rampup_minutes}")
        print(f"DEBUG: Calculated duration_minutes = {duration_minutes}")

        # Generate TCL script for Benchmark Run
        benchmark_run_tcl = f"""
# Set global database and benchmark type using dbset (HammerDB 5.0 strict syntax)
dbset db mssqls
dbset bm TPC-C

# Set MSSQL connection parameters using diset (HammerDB 5.0 syntax - 'connection' group)
diset connection mssqls_server {args.instance_name}
diset connection mssqls_uid {args.hammerdb_user}
diset connection mssqls_pass {args.hammerdb_user_password}
diset connection mssqls_authentication windows
diset connection mssqls_odbc_driver "ODBC Driver 17 for SQL Server"
diset connection mssqls_encrypt_connection false
diset connection mssqls_trust_server_cert false

# Set TPC-C benchmark specific parameters using diset (HammerDB 5.0 syntax - 'tpcc' group)
diset tpcc mssqls_dbase {args.db_name}
diset tpcc mssqls_driver timed ; # Use 'timed' driver for benchmark run
diset tpcc mssqls_count_ware {args.warehouses}
diset tpcc mssqls_total_iterations 0 ; # Set to 0 for continuous operation during duration
diset tpcc mssqls_num_vu {vu_count}
diset tpcc mssqls_rampup {rampup_minutes} ; # Value in minutes
diset tpcc mssqls_duration {duration_minutes} ; # Value in minutes

loadscript
vuset vu {vu_count}
vucreate
vurun

# We rely on HammerDB's internal timing for 'timed' driver. No explicit 'after' needed here unless problems persist.
# print vu metrics (removed as it might cause issues or is not supported in this version/context)

vudestroy
quit
"""
        benchmark_tcl_file = os.path.join(tcl_scripts_dir, f"run_benchmark_{args.warehouses}W_{vu_count}VU.tcl")
        with open(benchmark_tcl_file, "w") as f:
            f.write(benchmark_run_tcl)
        print(f"Generated TCL script: '{benchmark_tcl_file}'")

        results_file = os.path.join(results_dir, f"TPCC_Results_{args.warehouses}W_{vu_count}VU_{time.strftime('%Y%m%d_%H%M%S')}.txt")

        # Run benchmark
        if run_hammerdb_tcl_script(benchmark_tcl_file, f"benchmark for {vu_count} VUs", results_file=results_file):
            print(f"Benchmark for {vu_count} VUs completed successfully. Results saved to '{results_file}'.")
            # Print relevant metrics from the results file to console
            try:
                with open(results_file, "r") as f:
                    for line in f:
                        if "TPC-C Transactions" in line or "Total transactions" in line or "tpm" in line or "NOPM" in line:
                            print(line.strip())
            except FileNotFoundError:
                print(f"WARNING: Results file '{results_file}' not found after benchmark, cannot print summary.")
        else:
            print(f"WARNING: Benchmark for {vu_count} VUs failed crucially. See logs above.")
        
        print(f"--- Benchmark for {vu_count} Virtual Users Finished ---\n")

    print("--- HammerDB TPC-C Benchmark Script Finished ---")
    print(f"All generated TCL scripts are in '{tcl_scripts_dir}'")
    print(f"All benchmark results are in '{results_dir}'")

if __name__ == "__main__":
    main()
