import argparse
import pyodbc
import time
import sys

def run_sql_query(connection_string, query, db_name="master", autocommit=True):
    """Executes a SQL query against the specified database."""
    conn = None
    try:
        conn_str_with_db = f"{connection_string};DATABASE={db_name};"
        conn = pyodbc.connect(conn_str_with_db, autocommit=autocommit)
        cursor = conn.cursor()
        cursor.execute(query)
        if not autocommit:
            conn.commit()
        print(f"SQL query executed successfully via pyodbc on DB '{db_name}'.")
        return True
    except pyodbc.Error as ex:
        print(f"ERROR: SQL query failed on DB '{db_name}': {ex}")
        return False
    finally:
        if conn:
            conn.close()

def main():
    parser = argparse.ArgumentParser(description="HammerDB MSSQL Setup: Drops/Creates Database and User.")
    parser.add_argument("--instance-name", required=True, help="SQL Server instance name (e.g., 'localhost' or 'localhost\\SQLEXPRESS').")
    parser.add_argument("--sa-password", required=True, help="SQL Server 'sa' account password. Used for initial setup.")
    parser.add_argument("--db-name", default="MyTPCCDatabase", help="Name of the TPC-C database to create.")
    parser.add_argument("--hammerdb-user", default="my_hammerdb_user", help="Dedicated SQL Server login/user for HammerDB.")
    parser.add_argument("--hammerdb-user-password", required=True, help="Password for the dedicated HammerDB user. MUST be strong.")

    args = parser.parse_args()

    # ODBC connection string for initial setup using 'sa'
    odbc_conn_str_sa = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={args.instance_name};UID=sa;PWD={args.sa_password};"

    print("--- Starting HammerDB MSSQL Setup ---")

    # Step 1: Test SQL Connection using 'sa'
    print(f"\nAttempting SQL connection test to '{args.instance_name}' for user 'sa'...")
    if not run_sql_query(odbc_conn_str_sa, "SELECT 1;", db_name="master"):
        print("FATAL ERROR: Initial SQL connection test failed. Please check instance name, 'sa' password, and SQL Server status.")
        sys.exit(1)
    print("SQL Connection Test Successful.")

    # Step 2: Drop existing database if it exists
    print(f"\nAttempting to drop existing database '{args.db_name}' if it exists...")
    db_id_query = f"SELECT DB_ID(N'{args.db_name}');"
    try:
        conn = pyodbc.connect(odbc_conn_str_sa, autocommit=True)
        cursor = conn.cursor()
        cursor.execute(db_id_query)
        db_id = cursor.fetchone()[0]
        conn.close()
    except pyodbc.Error as ex:
        print(f"WARNING: Error checking if database '{args.db_name}' exists: {ex}. Assuming it does not exist.")
        db_id = None # Treat error as non-existent DB
    
    if db_id:
        print(f"Database '{args.db_name}' (ID: {db_id}) exists. Attempting to drop it...")
        # Put database in single user mode to drop
        if not run_sql_query(odbc_conn_str_sa, f"ALTER DATABASE [{args.db_name}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;", db_name="master"):
            print(f"ERROR: Failed to set database '{args.db_name}' to SINGLE_USER mode. Cannot drop database.")
            sys.exit(1)
        if not run_sql_query(odbc_conn_str_sa, f"DROP DATABASE [{args.db_name}];", db_name="master"):
            print(f"ERROR: Failed to drop database '{args.db_name}'.")
            sys.exit(1)
        print(f"Database '{args.db_name}' dropped successfully.")
    else:
        print(f"Database '{args.db_name}' does not exist, skipping drop.")

    # Step 3: Drop existing HammerDB login/user if they exist
    print(f"\nAttempting to drop existing login and user for '{args.hammerdb_user}' if they exist...")
    # Drop login (must be done from master)
    if not run_sql_query(odbc_conn_str_sa, f"IF EXISTS (SELECT * FROM sys.sql_logins WHERE name = N'{args.hammerdb_user}') DROP LOGIN [{args.hammerdb_user}];", db_name="master"):
        print(f"WARNING: Login '{args.hammerdb_user}' might not exist or could not be dropped. Continuing...")
    else:
        print(f"Login '{args.hammerdb_user}' dropped (if existed).")

    print(f"User '{args.hammerdb_user}' and login cleanup complete.")

    # Step 4: Create Database and HammerDB User
    print(f"\nCreating database '{args.db_name}' and login/user '{args.hammerdb_user}'...")
    # Create DB, set recovery model, and compatibility level
    if not run_sql_query(odbc_conn_str_sa,
                         f"CREATE DATABASE [{args.db_name}]; ALTER DATABASE [{args.db_name}] SET RECOVERY FULL; ALTER DATABASE [{args.db_name}] SET COMPATIBILITY_LEVEL = 160;",
                         db_name="master"):
        print(f"ERROR: Failed to create database '{args.db_name}'.")
        sys.exit(1)
    
    # Create Login
    if not run_sql_query(odbc_conn_str_sa,
                         f"CREATE LOGIN [{args.hammerdb_user}] WITH PASSWORD = N'{args.hammerdb_user_password}', CHECK_POLICY = OFF;",
                         db_name="master"):
        print(f"ERROR: Failed to create login '{args.hammerdb_user}'.")
        sys.exit(1)

    # Create User in the new DB and add to db_owner role
    # Note: connect to the newly created database to add the user
    odbc_conn_str_db = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={args.instance_name};DATABASE={args.db_name};UID=sa;PWD={args.sa_password};"
    if not run_sql_query(odbc_conn_str_db,
                         f"CREATE USER [{args.hammerdb_user}] FOR LOGIN [{args.hammerdb_user}]; ALTER ROLE [db_owner] ADD MEMBER [{args.hammerdb_user}];",
                         db_name=args.db_name):
        print(f"ERROR: Failed to create user '{args.hammerdb_user}' or add to 'db_owner' role in database '{args.db_name}'.")
        sys.exit(1)
    
    print(f"Database '{args.db_name}' and user '{args.hammerdb_user}' created successfully.")
    print("\n--- HammerDB MSSQL Setup Finished Successfully ---")

if __name__ == "__main__":
    main()
