import argparse
import subprocess
import os
import sys

# Global Configuration
hammerdb_cli_path = r"C:\Program Files\HammerDB\hammerdbcli.exe"
tcl_scripts_dir = os.path.join(os.path.expanduser("~"), "Downloads", "HammerDB_TCL_Scripts")

def run_hammerdb_tcl_script(script_path, log_prefix):
    """Runs a HammerDB CLI Tcl script, handling specific exit codes for known issues."""
    command = [hammerdb_cli_path, "tcl", "auto", script_path]
    print(f"\nRunning HammerDB CLI with script: '{script_path}' (using v5.0 syntax)")
    print(f"Executing: {' '.join(command)}")

    process = subprocess.run(command, capture_output=True, text=True, check=False) # Handle return code manually

    # Print all captured output to the console for immediate visibility
    print(f"\n--- HammerDB CLI STDOUT ({log_prefix}) ---")
    print(process.stdout)
    print(f"--- HammerDB CLI STDERR ({log_prefix}) ---")
    print(process.stderr)
    print("------------------------------------------\n")

    # Check specifically for the disableRaw error when exit code is 1
    if process.returncode == 1 and "invalid command name \"disableRaw\"" in process.stderr:
        print(f"WARNING: HammerDB CLI for {log_prefix} exited with code 1 due to 'disableRaw' error, but primary task likely succeeded.")
        # We'll treat this as a successful completion for the purpose of the Python script continuing
        return True
    elif process.returncode != 0:
        # Re-raise error for any other non-zero exit codes if success was expected
        print(f"FATAL ERROR: Command failed during {log_prefix} with exit code {process.returncode}")
        print(f"Please review the full output above for details.")
        return False
    else: # process.returncode == 0
        print(f"HammerDB CLI for {log_prefix} completed successfully.")
        return True

def main():
    parser = argparse.ArgumentParser(description="HammerDB Schema Build: Creates TPC-C Schema.")
    parser.add_argument("--instance-name", required=True, help="SQL Server instance name (e.g., 'localhost' or 'localhost\\SQLEXPRESS').")
    parser.add_argument("--db-name", default="MyTPCCDatabase", help="Name of the TPC-C database where schema will be built.")
    parser.add_argument("--hammerdb-user", default="my_hammerdb_user", help="Dedicated SQL Server login/user for HammerDB.")
    parser.add_argument("--hammerdb-user-password", required=True, help="Password for the dedicated HammerDB user.")
    parser.add_argument("--warehouses", type=int, required=True, help="Number of TPC-C warehouses for schema build.")

    args = parser.parse_args()

    os.makedirs(tcl_scripts_dir, exist_ok=True)

    print("--- Starting HammerDB Schema Build ---")

    # Generate TCL script for Schema Build
    print(f"\nGenerating TCL script for schema build for {args.warehouses} warehouses...")
    schema_build_tcl = f"""
# Set global database and benchmark type using dbset (HammerDB 5.0 strict syntax)
dbset db mssqls
dbset bm TPC-C

# Set MSSQL connection parameters using diset (HammerDB 5.0 syntax - 'connection' group)
diset connection mssqls_server {args.instance_name}
diset connection mssqls_uid {args.hammerdb_user}
diset connection mssqls_pass {args.hammerdb_user_password}
diset connection mssqls_authentication windows ; # Using Windows Authentication as it previously succeeded
diset connection mssqls_odbc_driver "ODBC Driver 17 for SQL Server"
diset connection mssqls_encrypt_connection false
diset connection mssqls_trust_server_cert false

# Set TPC-C benchmark specific parameters using diset (HammerDB 5.0 syntax - 'tpcc' group)
diset tpcc mssqls_dbase {args.db_name}
diset tpcc mssqls_driver test ; # Use 'test' driver for schema build
diset tpcc mssqls_count_ware {args.warehouses}
diset tpcc mssqls_total_iterations 1 ; # For schema build, 1 iteration is sufficient
diset tpcc mssqls_num_vu 1 ; # Single VU for schema build

loadscript
buildschema
quit
"""
    schema_build_tcl_file = os.path.join(tcl_scripts_dir, f"build_schema_{args.warehouses}W.tcl")
    with open(schema_build_tcl_file, "w") as f:
        f.write(schema_build_tcl)
    print(f"Generated TCL script: '{schema_build_tcl_file}'")

    # Run schema build
    if not run_hammerdb_tcl_script(schema_build_tcl_file, "schema build"):
        sys.exit(1) # Exit if schema build failed crucially

    print("\n--- HammerDB Schema Build Finished Successfully ---")

if __name__ == "__main__":
    main()
